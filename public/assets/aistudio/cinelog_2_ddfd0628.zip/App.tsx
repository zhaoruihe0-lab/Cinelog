import React, { useState, useEffect, useRef } from 'react';
import Layout from './components/Layout';
import MovieList from './components/MovieList';
import MovieForm, { MovieFormHandle } from './components/MovieForm';
import MovieCard from './components/MovieCard';
import Profile from './components/Profile';
import { Movie, ViewState } from './types';
import { storage } from './services/storage';

const App: React.FC = () => {
  const [view, setView] = useState<ViewState>('library');
  const [movies, setMovies] = useState<Movie[]>([]);
  const [selectedMovie, setSelectedMovie] = useState<Movie | null>(null);
  const [movieToEdit, setMovieToEdit] = useState<Movie | undefined>(undefined);
  
  const formRef = useRef<MovieFormHandle>(null);

  // Load movies from DB (with Migration check) on mount
  useEffect(() => {
    const initData = async () => {
        // 1. Check for legacy LocalStorage data
        const localMovies = localStorage.getItem('cineLogMovies');
        if (localMovies) {
            try {
                console.log("Migrating data from LocalStorage to IndexedDB...");
                const parsed = JSON.parse(localMovies);
                await storage.saveMovies(parsed);
                // Clear legacy data to free up space
                localStorage.removeItem('cineLogMovies');
            } catch (e) {
                console.error("Migration failed", e);
            }
        }

        // 2. Load from IndexedDB
        try {
            const dbMovies = await storage.getMovies();
            setMovies(dbMovies);
        } catch (e) {
            console.error("Failed to load movies from DB", e);
        }
    };

    initData();
  }, []);

  // Save movies to DB whenever they change
  useEffect(() => {
    if (movies.length > 0) {
        storage.saveMovies(movies).catch(err => console.error("DB Save Failed:", err));
    }
  }, [movies]);

  const handleSaveMovie = (movieData: Movie) => {
    if (movieToEdit) {
      // Update existing
      setMovies((prev) => prev.map(m => m.id === movieData.id ? movieData : m));
      setMovieToEdit(undefined);
    } else {
      // Add new
      setMovies((prev) => [movieData, ...prev]);
    }
    
    // If we were editing a specific movie that was open, update selection too
    if (selectedMovie && selectedMovie.id === movieData.id) {
        setSelectedMovie(movieData);
        setView('details');
    } else {
        setView('library');
    }
  };

  // Handle updates from Detail View (e.g. Stickers)
  const handleUpdateMovie = (updatedMovie: Movie) => {
      setMovies((prev) => prev.map(m => m.id === updatedMovie.id ? updatedMovie : m));
      setSelectedMovie(updatedMovie);
  };

  const handleDeleteMovie = (id: string) => {
    if (window.confirm('Are you sure you want to delete this record?')) {
      setMovies((prev) => prev.filter(m => m.id !== id));
      setSelectedMovie(null);
      setMovieToEdit(undefined);
      setView('library');
    }
  };

  const handleSelectMovie = (movie: Movie) => {
    setSelectedMovie(movie);
    setView('details');
  };

  const handleEditMovie = (movie: Movie) => {
    setMovieToEdit(movie);
    setView('add'); // Re-use 'add' view for edit
  };

  const handleBackToList = () => {
    setSelectedMovie(null);
    setMovieToEdit(undefined);
    setView('library');
  };
  
  const handleCancelForm = () => {
      setMovieToEdit(undefined);
      if (selectedMovie) {
          setView('details');
      } else {
          setView('library');
      }
  }

  // Handle FAB Click from Layout
  const handleFabClick = () => {
      if (view === 'add') {
          // If in Add/Edit mode, trigger Submit
          if (formRef.current) {
              formRef.current.submit();
          }
      } else {
          // Otherwise switch to Add mode
          setMovieToEdit(undefined);
          setView('add');
      }
  };

  const handleNavChange = (newView: ViewState) => {
      if (newView === 'add') {
          setMovieToEdit(undefined);
      }
      setView(newView);
  };

  // Data Import Handler
  const handleImportData = (importedMovies: Movie[]) => {
      setMovies(importedMovies);
      alert(`Sync Complete: ${importedMovies.length} logs restored.`);
      setView('library');
  };

  return (
    <Layout currentView={view} onChangeView={handleNavChange} onFabClick={handleFabClick}>
      {view === 'library' && (
        <MovieList 
            movies={movies} 
            onSelectMovie={handleSelectMovie} 
        />
      )}
      
      {view === 'add' && (
        <MovieForm 
          ref={formRef}
          onSave={handleSaveMovie} 
          onCancel={handleCancelForm} 
          onDelete={handleDeleteMovie}
          initialData={movieToEdit}
        />
      )}

      {view === 'details' && selectedMovie && (
        <MovieCard 
          movie={selectedMovie} 
          onBack={handleBackToList} 
          onEdit={handleEditMovie}
          onDelete={handleDeleteMovie}
          onUpdate={handleUpdateMovie}
        />
      )}

      {view === 'profile' && (
          <Profile 
            movies={movies} 
            onDataImport={handleImportData}
          />
      )}
    </Layout>
  );
};

export default App;